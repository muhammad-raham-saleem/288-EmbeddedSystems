#ifndef OBJECTS_H_
#define OBJECTS_H_

struct object {
    int startAngle;
    int endAngle;
    float distance;
    float radialWidth;
    int middleAngle;
};

#endif
