#include "cyBot_Scan.h"
#include "cyBot_uart.h"
#include "Timer.h"
#include "lcd.h"
#include "stdio.h"

/*
Author: Christine Chen
Section: C
Date: 2/9/2026

For Lab 3. Starter code for main CyBot scan calibration and sending strings between PuTTY and CyBot instead of just char's.
*/
void cyBot_sendString(char str[]);
// calibration
/*
int main(void){
    // initialization
    timer_init();
    lcd_init();
    cyBOT_init_Scan(0b0111);
    cyBot_uart_init();

    cyBOT_SERVO_cal();
    return 0;
}
*/

///*
int main(void){
    // initialization
    timer_init();
    lcd_init();
    cyBOT_init_Scan(0b0111);
    cyBot_uart_init();

    /*while(1){
      char x = cyBot_getByte();
      lcd_printf("%c", x);

      char str[] = {};
      // sets length of string, sets str to desired string
      sprintf(str, "Got %c", x);
      cyBot_sendString(str);
    }*/


    // manual calibration of left/right values
    right_calibration_value = 311500;
    left_calibration_value = 1303750;

    int i;
    cyBOT_Scan_t scan;
    cyBot_sendString("Degrees\tPING Distance (cm)\n");

    // sweep scans (0-180 degrees) and prints angle and distance from detected objects
    for(i = 0; i < 180; i+=2){
        cyBOT_Scan(i, &scan);

        char angle[] = {};
        sprintf(angle, "%i\t", i);
        cyBot_sendString(angle);

        char scanDistance[] = {};
        sprintf(scanDistance, "%f\n", scan.sound_dist);
        cyBot_sendString(scanDistance);
    }
}
//*/


void cyBot_sendString(char str[]) {
    int len = strlen(str);
    int j;

    // sends one char at a time
    for(j = 0; j < len; j++){
        cyBot_sendByte(str[j]);
    }
}

