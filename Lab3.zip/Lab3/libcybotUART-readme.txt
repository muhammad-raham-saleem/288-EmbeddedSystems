libcybotUART.txt is a pre-compiled library for CyBot/Human UART communication. 

The file extension must be changed from .txt to .lib after copying into your folder.

IMPORTANT: Do not open the file as it may corrupt the file causing a Linker error. Only copy/download the file. If it is corrupted, download again.